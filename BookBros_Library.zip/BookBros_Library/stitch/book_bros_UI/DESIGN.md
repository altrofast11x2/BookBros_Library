---
name: Academic Precision
colors:
  surface: '#f9f9fc'
  surface-dim: '#dadadc'
  surface-bright: '#f9f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f6'
  surface-container: '#eeeef0'
  surface-container-high: '#e8e8ea'
  surface-container-highest: '#e2e2e5'
  on-surface: '#1a1c1e'
  on-surface-variant: '#42474f'
  inverse-surface: '#2f3133'
  inverse-on-surface: '#f0f0f3'
  outline: '#727780'
  outline-variant: '#c2c7d1'
  surface-tint: '#2d6197'
  primary: '#00355f'
  on-primary: '#ffffff'
  primary-container: '#0f4c81'
  on-primary-container: '#8ebdf9'
  inverse-primary: '#a0c9ff'
  secondary: '#496173'
  on-secondary: '#ffffff'
  secondary-container: '#cce6fb'
  on-secondary-container: '#4f6779'
  tertiary: '#2c343f'
  on-tertiary: '#ffffff'
  tertiary-container: '#434b56'
  on-tertiary-container: '#b3bbc8'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d2e4ff'
  primary-fixed-dim: '#a0c9ff'
  on-primary-fixed: '#001c37'
  on-primary-fixed-variant: '#07497d'
  secondary-fixed: '#cce6fb'
  secondary-fixed-dim: '#b1cade'
  on-secondary-fixed: '#021e2d'
  on-secondary-fixed-variant: '#32495a'
  tertiary-fixed: '#dbe3f1'
  tertiary-fixed-dim: '#bfc7d4'
  on-tertiary-fixed: '#141c26'
  on-tertiary-fixed-variant: '#3f4752'
  background: '#f9f9fc'
  on-background: '#1a1c1e'
  surface-variant: '#e2e2e5'
  status-available: '#2D8A4E'
  status-borrowed: '#D93025'
  status-reserved: '#F29900'
  surface-subtle: '#F8F9FA'
  border-standard: '#D1D5DB'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  status-label:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 12px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: auto
  max-width: 1200px
---

## Brand & Style

The design system is engineered for the high-context environment of university academia. It balances the rigor of traditional research with the efficiency of modern productivity tools. The personality is **authoritative yet accessible**, fostering trust through clarity and a systematic approach to information architecture.

The chosen style is **Corporate / Modern** with a focus on **Systematic Minimalism**. It utilizes a structured grid, generous whitespace, and a high-contrast typographic hierarchy to ensure that students can navigate complex catalogs without cognitive overload. Visual embellishments are minimized in favor of functional clarity and rapid data retrieval.

- **Trust:** Established through a stable, blue-centric palette and structured layouts.
- **Clarity:** Driven by rigorous typography and a clear separation of interactive elements.
- **Efficiency:** Optimized for "search-to-action" workflows with high-visibility status indicators.

## Colors

The palette is anchored by a "Classic Academic Blue" that evokes institutional reliability. The color system is strictly functional, using color primarily to communicate state and hierarchy rather than for decorative purposes.

- **Primary:** A deep, authoritative blue used for core branding, primary actions, and active navigation states.
- **Secondary:** A muted slate blue for supporting information and secondary UI elements.
- **Tertiary:** A very light blue tint used for large surface areas, such as selected states or background accents, to maintain a cool, focused atmosphere.
- **Status Colors:** These are semantically mapped to the library's operations:
    - **Available (Green):** Signals immediate actionability.
    - **Borrowed (Red):** Indicates unavailability or urgent due dates.
    - **Reserved (Amber):** Indicates a pending or transitional state.

The default mode is **Light**, mimicking the legibility of printed academic journals.

## Typography

This design system uses a triple-font approach to maximize information density and legibility:

1.  **Manrope (Headlines):** A modern, geometric sans-serif that provides a clean, professional "tech-academic" look for titles and section headers.
2.  **Inter (Body):** The workhorse font for all reading experiences, chosen for its exceptional legibility on digital screens, especially for book descriptions and metadata.
3.  **JetBrains Mono (Labels/Metadata):** Used sparingly for "hard" data like ISBNs, call numbers, and dates. This adds a layer of precision and distinguishes technical data from narrative text.

Large headlines (Display/Headline-LG) should use tighter letter-spacing for a more editorial feel. Body text maintains standard spacing to ensure long-form readability.

## Layout & Spacing

The design system follows a **Fixed Grid** model for desktop to maintain the focused feel of a research portal, while transitioning to a **Fluid Grid** for mobile.

- **Desktop (1024px+):** A 12-column grid with a max-width of 1200px. Content is centered. Gutters are fixed at 24px to provide enough breathing room between book cards.
- **Tablet (768px - 1023px):** An 8-column fluid grid with 24px margins.
- **Mobile (<767px):** A 4-column fluid grid with 16px margins. 

The spacing rhythm is based on a **4px baseline**, with standard increments (8, 16, 24, 40, 64) used to define the relationship between elements. Vertical rhythm is strictly enforced in the book list views to ensure a scan-friendly layout.

## Elevation & Depth

To maintain a "modern academic" aesthetic, this design system avoids heavy drop shadows. Instead, it utilizes **Tonal Layers** and **Low-contrast Outlines** to create hierarchy.

- **Level 0 (Background):** The base canvas, typically white or a very subtle gray (`#F8F9FA`).
- **Level 1 (Cards/Surface):** White surfaces with a 1px border (`#D1D5DB`). No shadow. This is the standard state for book cards in the search results.
- **Level 2 (Hover/Active):** When a user interacts with a card, a soft, high-diffusion shadow is applied (0px 4px 20px rgba(0, 0, 0, 0.05)) to signify elevation without breaking the minimal aesthetic.
- **Modals/Overlays:** Use a slightly stronger shadow and a backdrop blur (12px) to dim the underlying search results, focusing the student's attention on the specific transaction (e.g., confirming a reservation).

## Shapes

The shape language is **Soft (Level 1)**. 

- **UI Elements (Buttons, Inputs):** 0.25rem (4px) corner radius. This sharp-but-not-harsh radius communicates precision and efficiency.
- **Containers (Cards, Modals):** 0.5rem (8px) corner radius to provide a slight visual distinction from interactive elements.
- **Book Covers:** Should maintain their natural rectangular shape with a minimal 2px radius to avoid looking like "bubbles," preserving the tactile feel of physical books.

## Components

### Buttons
- **Primary:** Solid `#0F4C81` with white text. Used for "Search," "Borrow," and "Login."
- **Secondary:** Outlined with `#0F4C81` and transparent background. Used for "Reserve" or "Extend Borrowing."
- **Ghost:** No border, primary color text. Used for "Cancel" or "View All."

### Search Interface
The search bar is the most critical component. It should be pinned or highly prominent, using a 1px border that thickens or changes to the primary color on focus. Incorporate a "Category Tag" system within the search results to allow for rapid filtering.

### Status Indicators (Chips)
Small, high-contrast badges used in lists and detail views:
- **Available:** Green background (10% opacity) with dark green text.
- **Borrowed:** Red background (10% opacity) with dark red text.
- **Reserved:** Amber background (10% opacity) with dark amber text.

### Cards
Book cards must prioritize the title and availability status. Metadata (Author, Call Number) should use the `label-caps` (JetBrains Mono) style for a technical, organized feel.

### Input Fields
Inputs should be clean with 1px borders. Use `Inter` for input text. Labels should always be visible above the field (not as floating placeholders) to ensure accessibility during long forms like registration.