import { readFileSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';

const webRoot = join(dirname(fileURLToPath(import.meta.url)), '..');
const manifest = JSON.parse(readFileSync(join(webRoot, 'stitch-manifest.json'), 'utf8'));

const requiredKoFiles = [
  'pages/home.html',
  'pages/search.html',
  'pages/book-detail.html',
  'pages/login.html',
  'pages/signup.html',
  'pages/mypage.html',
  'pages/admin/index.html',
  'js/site.js',
];

requiredKoFiles.forEach((file) => {
  const path = join(webRoot, file);
  assert.ok(existsSync(path), `missing required file: ${file}`);
});

manifest.prdRequiredScreens.forEach((screen) => {
  const match = manifest.pages.ko.find((p) => p.file.includes(screen));
  assert.ok(match, `manifest missing PRD screen mapping: ${screen}`);
});

const bookDetail = readFileSync(join(webRoot, 'pages/book-detail.html'), 'utf8');
assert.ok(bookDetail.includes('lang="ko"'), 'book-detail must be Korean');
assert.ok(!bookDetail.includes('Reviews'), 'book-detail must not include Reviews tab');
assert.ok(bookDetail.includes('예약 신청'), 'book-detail must include reserve action');
assert.ok(bookDetail.includes('대출 신청'), 'book-detail must include borrow action');

const login = readFileSync(join(webRoot, 'pages/login.html'), 'utf8');
assert.match(login, /아이디/);
assert.match(login, /비밀번호/);

const signup = readFileSync(join(webRoot, 'pages/signup.html'), 'utf8');
assert.match(signup, /이름/);
assert.match(signup, /회원가입/);

const admin = readFileSync(join(webRoot, 'pages/admin/index.html'), 'utf8');
assert.match(admin, /도서 등록/);
assert.match(admin, /반납 처리/);

console.log('manifest.test.mjs: all checks passed');
