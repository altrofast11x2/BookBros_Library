/** @typedef {'guest' | 'user' | 'admin'} AuthState */
/** @typedef {'home' | 'search' | 'mypage' | 'admin'} ActiveNav */

/**
 * @param {{ auth?: AuthState; activeNav?: ActiveNav; base?: string }} config
 */
const renderSiteHeader = (config = {}) => {
  const auth = config.auth ?? document.body.dataset.auth ?? 'guest';
  const activeNav = config.activeNav ?? document.body.dataset.activeNav ?? '';
  const base = config.base ?? document.body.dataset.base ?? '.';

  const href = (path) => `${base}/${path}`.replace(/\/+/g, '/').replace(/^\.\//, '');

  const navClass = (key) =>
    key === activeNav
      ? 'text-primary font-bold border-b-2 border-primary pb-1 font-body-md text-body-md'
      : 'text-on-surface-variant hover:text-primary transition-colors font-body-md text-body-md';

  const authActions =
    auth === 'admin'
      ? `<a href="${href('admin/index.html')}" class="text-on-surface-variant hover:text-primary px-4 py-2 rounded-lg font-body-md">관리자</a>
         <a href="${href('login.html')}" class="text-error font-bold px-4 py-2 rounded-lg hover:bg-error-container/20 font-body-md">로그아웃</a>`
      : auth === 'user'
        ? `<a href="${href('mypage.html')}" class="bg-primary-container text-on-primary px-6 py-2 rounded-lg font-bold hover:opacity-90 active:scale-95">마이페이지</a>
           <a href="${href('login.html')}" class="text-on-surface-variant hover:bg-surface-subtle px-4 py-2 rounded-lg font-body-md">로그아웃</a>`
        : `<a href="${href('login.html')}" class="text-on-surface-variant hover:bg-surface-subtle px-4 py-2 rounded-lg font-body-md active:scale-95">로그인</a>
           <a href="${href('signup.html')}" class="bg-primary text-on-primary px-6 py-2 rounded-lg font-bold hover:opacity-90 active:scale-95">회원가입</a>`;

  const adminLink =
    auth === 'admin'
      ? `<a class="${navClass('admin')}" href="${href('admin/index.html')}">관리자</a>`
      : '';

  return `<nav class="flex items-center justify-between px-margin-desktop py-4 max-w-max-width mx-auto">
<div class="flex items-center gap-8">
<a class="flex items-center gap-2" href="${href('home.html')}">
<img alt="Book Bros Logo" class="h-10 w-10" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAfqMxVCjYcnstEaa2qzZZXBswX8BGD1WoPCugs-sm4WcYJlSmLfUi_W7c9q_XTcCfAbQkR5P2jG9MiNL61OdBCP5PFbR1yrGwmcf959A-gNl1MC4xan7HB6gb64sHh2dy3jxeCm0l1q96lOmH-CAV913myHIoFNhwzwkvciMRoUEL1U_OCSVzvPm1TTguu4dhQli7f-VLqVugYWwyL97g_-kKkZeEcTPcT1H2Gc2eFwNtrwVv6kGBP2-KfJrD6qMMhAYxj3rw84wc"/>
<span class="font-headline-md text-headline-md font-bold text-primary">Book Bros</span>
</a>
<div class="hidden md:flex items-center gap-6">
<a class="${navClass('search')}" href="${href('search.html')}">도서 목록</a>
<a class="${navClass('mypage')}" href="${href('mypage.html')}">마이페이지</a>
${adminLink}
</div>
</div>
<div class="flex items-center gap-4">${authActions}</div>
</nav>`;
};

document.addEventListener('DOMContentLoaded', () => {
  const header = document.getElementById('site-header');
  if (!header) return;
  header.innerHTML = renderSiteHeader();
});
